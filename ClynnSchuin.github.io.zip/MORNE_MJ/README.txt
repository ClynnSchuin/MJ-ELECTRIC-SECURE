MJ ELECTRIC SECURE WEBSITE PACKAGE
----------------------------------

FILES INCLUDED:
- index.html
- about.html
- services.html
- contact.html
- css/style.css
- js/main.js
- assets/images/ (placeholders)

INSTRUCTIONS:
1. Place all files exactly as in the folder structure.
2. Replace placeholder images with real project photos using the same filenames.
3. Host via any web server or upload to GitHub Pages / Truehost.

CONTACT:
📧 mjelectricsecure@gmail.com
📞 083 348 8815
