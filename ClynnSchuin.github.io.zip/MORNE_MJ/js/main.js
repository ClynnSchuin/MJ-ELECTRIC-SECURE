// MJ Electric Secure Main JS
document.addEventListener("DOMContentLoaded", () => {
    console.log("MJ Electric Secure website loaded successfully.");
});
